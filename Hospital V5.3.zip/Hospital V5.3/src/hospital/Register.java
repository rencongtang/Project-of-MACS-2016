package hospital;

public class Register implements Comparable{

    private String roomNumber;
    private String patientName;
    private Room room=null;
    private Department department=null;
    public Register(){
    }
    public void setRoomNumber(String roomNumber){
        this.roomNumber = roomNumber;
    }
    public String getRoomNumber(){
        return roomNumber;
    }
    public void setPatientName(String patientName){
        this.patientName = patientName;
    }
    public String getPatientName(){
        return patientName;
    }
    public void setRoom(Room room){
        this.room=room;
    }
    public Room getRoom(){
        return room;
    }
    public void setDepartment(Department department){
        this.department=department;
    }
    public Department getDepartment(){
        return department;
    }
    @Override
    public int compareTo(Object o) {
        // TODO Auto-generated method stub
        return 0;
    }

}
