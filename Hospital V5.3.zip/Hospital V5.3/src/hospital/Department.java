package hospital;
/***
 * what I'm supposed to finish in this part:
 * 1> I need to build a new class named Department, in this class, it contains patient Rooms,
 * special waitingRooms, devices and the devices which is equipmented.
 * 2> I need to add two new parameter into patient, which is the level of sick and is that necessary to
 * stay in a single patients room
 * 3> I need to make the department has the ability to add and remove different devices into equipment
 */


public class Department implements Comparable{

    private String departmentName;
    //	private int Rooms;//To save how many rooms in this department
    private LinkedList patientRooms = new LinkedList();
    private WaitingRoom waitingRoom=new WaitingRoom();
    private LinkedList devices = new LinkedList();
//    private LinkedList equipments = new LinkedList();


    public Department(String departmentName){//Set the name of department
        this.departmentName = departmentName;
    }

    public WaitingRoom getWaitingRoom(){
        return waitingRoom;
    }
    public int singleWaitingRoomCount(){

        return waitingRoom.singleCount();
    }

    public int normalWaitingRoomCount(){

        return waitingRoom.normalCoint();
    }

    public int mainWaitingRoomCount(){

        return waitingRoom.waitingRoomCount();
    }

    public void addPatientRooms(Room r){//add patient rooms
        patientRooms.addLast(r);
    }

    public Room getRoom(int n){
        return (Room)patientRooms.get(n);
    }

    public String getDepartmentName(){
        return departmentName;
    }

//    public void setDevices(int capacity){//Set devices
//        devices = new Vector();
//    }

    public void addDevice(String device){//add
        devices.addLast(device);
    }

    public void showDevices(){
        System.out.println(devices);
    }

    public int size(){
        return patientRooms.size();
    }

//    public void addEquipments(int i){
//
//        Comparable a = devices.get(i);
//        equipments.addFirst(a);
//    }

//    public void removeEquipments(int i){
//
//        equipments.remove(i);;
//    }

//    public void showEquipments(){
//        System.out.println(equipments);
//    }

    public void addToWaitingRoom(Patient p){//add patients to the waiting room
        waitingRoom.addToNormal(p);
    }

    public Room findRoom(String roomName){

        for(int k=0;k<patientRooms.size();k++){
            Room getRoom=(Room)patientRooms.get(k);
            if( getRoom.getRoomName()==roomName){
                return getRoom;
            }

        }
        return null;
    }


    public void addBackToSingleWaitingRoom(Patient p1){

        waitingRoom.returnToSing(p1);
        System.out.println("Patient: "+p1.getName()+" has been sent back to waiting room");
    }

    public void addBackToNormalWaitingRoom(Patient p2){

        waitingRoom.returnToNormal(p2);
        System.out.println("Patient: "+p2.getName()+" has been sent back to waiting room");
    }

    public Patient outWaitingRoom(){
        return (Patient) waitingRoom.signOut();
    }

    public Patient outSingle(){
        return (Patient) waitingRoom.signOutSingle();
    }

    public Patient outNormal(){
        return (Patient) waitingRoom.signOutNormal();
    }

    public Room findSingleRoom(){

        for(int i=0;i<patientRooms.size();i++){
            Room room = (Room)patientRooms.get(i);
            if(room.getCapacity()==1&&room.patientNumbers()==0){
                return room;
            }
        }
        return null;

    }

    public PriorityQueue findAvailableRoom(){
        PriorityQueue rooms=new PriorityQueue();
        for(int i=0;i<patientRooms.size();i++){
            Room room =(Room)patientRooms.get(i);
            if((room.getCapacity()>room.patientNumbers())&&(room.getCapacity()>1)){
                rooms.push(room,1);
            }
            else if((room.getCapacity()>room.patientNumbers())&&(room.getCapacity()==1)){
                rooms.push(room,2);
            }
        }
        return rooms;
    }

    //To sign in a patient into a patient room, it can pop patients out of WR automaticlly, and what I need to take into consider is
    //is he want a single room at first
    public Register signIntoPatientRoom(Patient patient,Room patientRoom){

        for(int i=0;i<patientRooms.size();i++) {
            Room room = (Room) patientRooms.get(i);

            if(room==patientRoom) {
                int capacity = room.getCapacity();

                Register register=new Register();
                register = room.signIn(patient);
				//System.out.println("patient "+patient.getName()+" has been sign in "+room.getRoomNumber());
                return register;
            }
        }
        return null;
    }

    public int getPatientNumberInWaitingRoom(){
        return waitingRoom.getPatientNumber();
    }

    public boolean hasDevice(String deviceName){
        if(devices.size()>0){

            for(int i=0;i<devices.size();i++){
                String device=(String) devices.get(i);
                if(device==deviceName) return true;
            }
        }
        return false;
    }

    public LinkedList getPatientRooms(){
        return patientRooms;
    }

    @Override
    public int compareTo(Object o) {
        // TODO Auto-generated method stub
        return 0;
    }

    public String toString() {
        String s = "[";
        s+="Department Name:";
        s+=departmentName+" ";
        s+="devices:";
        s+=devices+" ";
//        s+="equipments:";
//        s+=equipments+" ";
        s+="Rooms:";
        s+=patientRooms;
        s+="WaitingRooms:";
        s+=waitingRoom;
        s+="]";
        return s;
    }

}
