package hospital;



/**
 * Created by rencongtang on 04/01/2017.
 */

public class Graph {
    public class Node implements Comparable{
        private Comparable info;
        private Vector edges;
        private Boolean visited=false;
        private Boolean inStack=false;


        public Node(Comparable label){
            info=label;
            edges=new Vector();
        }



        public void addEdge(Edge e){
            edges.add(e);
        }

        public int compareTo(Object o){
            //Two nodes are equal if they have the same label
            Node n=(Node)o;
            return n.info.compareTo(info);
        }

        public Comparable getLabel(){
            return info;
        }

        public Vector getEdges(){
            return edges;
        }

        public void setVisited(){
            visited=true;
        }

        public Boolean getVisited(){
            return visited;
        }

        public void setInStack(){
            inStack=true;
        }

        public Boolean getInStack(){
            return inStack;
        }
        public Edge findEdge(Node to){
            for(int i=0;i<edges.size();i++){
                Edge edge=(Edge)edges.get(i);
                if(edge.getTo()==to){
                    return edge;
                }
            }
            return null;
        }
    }

    private class Edge implements Comparable{
        private Node toNode;
        private int weight;


        public Edge(Node to,int weight){
            toNode=to;
            this.weight=weight;
        }

        public int compareTo(Object o){
            // two edges are equal if they point
            // to the same node.
            // this assumes that the edges are
            // starting from the same node !!!
            Edge n=(Edge)o;
            return n.toNode.compareTo(toNode);
        }
        public Node getTo(){
            return toNode;
        }
        public int getWeight(){
            return weight;
        }
    }
    public class NodeElement implements Comparable{
        private Node node=new Node(null);
        private int weightFromStart;
        private Node previous;

        public void setNode(Node node){
            this.node=node;
        }
        public void setWeight(int weight){
            this.weightFromStart=weight;
        }
        public void setPrevious(Node previous){
            this.previous=previous;
        }
        public Node getNode(){
            return node;
        }
        public int getWeight(){
            return weightFromStart;
        }
        public Node getPrevious(){
            return previous;
        }
        public int compareTo(Object o){
            Node n=(Node)o;
            return n.compareTo(o);
        }
    }

    private LinkedList nodes;
    public LinkedList getNodes(){
        return nodes;
    }
    public Graph(){
        nodes=new LinkedList();
    }

    public void addNode(Comparable label){
        nodes.addLast(new Node(label));
    }


    public Node findNode(Comparable nodeLabel){
        Node res=null;
        for(int i=0;i<nodes.size();i++){
            Node n=(Node)nodes.get(i);
            if(n.getLabel()==nodeLabel){
                res=n;
                break;
            }
        }
        return res;
    }

    public void addEdge(Comparable nodeLabel1,Comparable nodeLabel2,int weight){
        Node n1=findNode(nodeLabel1);
        Node n2=findNode(nodeLabel2);
        n1.addEdge(new Edge(n2,weight));//this addEdge is for Node Class rather than Graph class
    }

//    private void DFS(Node current){
//
//        current.visited = true;
//
//        for(int i=0;i<current.edges.size();i++) {
//            Edge e = (Edge)current.edges.get(i);
//            Node next = (Node)e.toNode;
//            if(!next.visited) DFS(next);
//        }
//    }
//
//    public void DFS(){
//        for(int i=0;i<nodes.size();i++){
//            Node current = (Node)nodes.get(i);
//            current.visited = false;
//        }
//        for(int i=0;i<nodes.size();i++) {
//            Node current = (Node)nodes.get(i);
//            if(!current.visited) DFS(current);
//        }
//    }
    // The function to find shortest paths from given vertex. It
    // uses recursive topologicalSortUtil() to get topological
    // sorting of given graph


    public Vector findTheShortestPath_Dijkstra(Node startNode){
        //creat a chart first
        Vector chart=new Vector();
        Vector visited=new Vector();
        Vector nonvisited=new Vector();
        for(int i=0;i<nodes.size();i++){
            NodeElement nl=new NodeElement();
            Node node=(Node)nodes.get(i);
            nonvisited.add(node);
            nl.setNode(node);
            if(node==startNode){
                nl.setWeight(0);
                nl.setPrevious(startNode);
            }
            else {
                nl.setWeight(1000);
                nl.setPrevious(null);
            }
            chart.add(nl);

        }
        //make visited vector and not visited

        //make a current
        Node current=startNode;
        int weightFromStart=0;
        while(nonvisited.size()!=0){
            //initial weight from start

            //get the weight from start, take into 2 situations
            Vector edges=current.getEdges();
            Node previous=findChart(current,chart).previous;
            if(current==previous){
                weightFromStart=0;
            }
            else {
                if(previous!=null){
                    weightFromStart+=((Edge)previous.findEdge(current)).getWeight();
                }
            }
            //generate the new from weight
            for(int i=0;i<edges.size();i++){
                Edge edge=(Edge) edges.get(i);
                Node node=edge.toNode;
                if(nodes.contains(node)){
                    int weight=edge.getWeight();
                    int newWeightFromStart=weightFromStart+weight;

                    upDate(node,newWeightFromStart,current,chart);
                }

            }
            visited.add(current);
            int index=nonvisited.find(current);
            nonvisited.remove(index);
            Edge minEdge=null;
            int minWeight=1000;
            for(int j=0;j<edges.size();j++){
                Edge edge=(Edge) edges.get(j);
                int weight=edge.getWeight();
                Node to=edge.toNode;
                if((weight<minWeight)&&(nonvisited.contains(to))) {
                    minEdge=edge;
                    minWeight=weight;
                }
            }
            if(minEdge!=null){
                current=minEdge.toNode;
            }
            else current=(Node) nonvisited.getFirst();

        }
        return chart;

    }
    public NodeElement findChart(Node node,Vector chart){
        for(int i=0;i<chart.size();i++){
            NodeElement nl=(NodeElement)chart.get(i);
            if(nl.getNode()==node){
                return nl;
            }
        }
        return null;
    }
    public void upDate(Node node,int weight,Node previous,Vector chart){
        for(int i=0;i<chart.size();i++){
            if((((NodeElement)chart.get(i)).getNode()==node)&&(((NodeElement)chart.get(i)).getWeight()>weight)){
                ((NodeElement)chart.get(i)).setWeight(weight);
                ((NodeElement)chart.get(i)).setPrevious(previous);
            }
        }
    }

    public int findShortest(Comparable label1,Comparable label2){
        Node start=findNode(label1);
        Node end=findNode(label2);
        Vector chart=findTheShortestPath_Dijkstra(start);
        NodeElement found=findChart(end,chart);
        return (int)found.getWeight();
    }
    public int findShortestPlus(Comparable label1,Comparable label2,Comparable label3){
        Node start=findNode(label1);
        Node center=findNode(label2);
        Node end=findNode(label3);
        int a=findShortest(label1,label2);
        int b=findShortest(label2,label3);
        return a+b;
    }
    public LinkedList shortestLabelPlus(Comparable label1,Comparable label2,Comparable label3){
        LinkedList a=shortestLabel(label1,label2);
        LinkedList b=shortestLabel(label2,label3);
        for(int i=1;i<b.size();i++){//Don't add again
            a.addLast(b.get(i));
        }
        return a;
    }
    public LinkedList shortestLabel(Comparable label1,Comparable label2){
        Node start=findNode(label1);
        Node end=findNode(label2);
        Node current=end;
        Vector chart=findTheShortestPath_Dijkstra(start);
        LinkedList linkedList=new LinkedList();
        linkedList.addLast(label2);
        while(current!=start){
            NodeElement found=findChart(current,chart);
            Node previous=found.getPrevious();
            linkedList.addFirst(previous.getLabel());
            current=previous;
        }
        return linkedList;
    }

    public boolean isConnencted(Comparable nodeLabel1 , Comparable nodeLabel2 ) {
        Node startState = findNode(nodeLabel1 );
        Node endState = findNode(nodeLabel2 );
        Stack toDoList = new Stack();
        toDoList.push(startState );
        while (! toDoList . empty ()){
            Node current = (Node)toDoList.pop();
            if ( current == endState )
                return true ;
            else{
                for (int i=0; i<current.edges.size(); i++){
                    Edge e = (Edge)current.edges.get(i);
                    toDoList.push(e.toNode);
                }
            }
        }
        return false;
    }

    public int findShortestMus(Comparable label1,Comparable label2,Comparable label3){

        Node node=findNode(label2);
        Node backnode=new Node(label2);
        for(int i=0;i<nodes.size();i++){
            if(((Node)nodes.get(i)).getLabel()==label2){
                backnode=(Node)nodes.get(i);
                nodes.remove(i);
                break;
            }

        }

        int get=findShortest(label1,label3);
        nodes.addLast(backnode);
        return get;
    }

    public LinkedList shortestLabelMus(Comparable label1,Comparable label2,Comparable label3){
        Node node=findNode(label2);
        Node backnode=new Node(label2);
        for(int i=0;i<nodes.size();i++){
            if(((Node)nodes.get(i)).getLabel()==label2){
                backnode=(Node)nodes.get(i);
                nodes.remove(i);
                break;
            }

        }

        LinkedList get=shortestLabel(label1,label3);
        nodes.addLast(backnode);
        return get;
    }

    public String toString(){
        String s=new String();
        for(int i=0;i<nodes.size();i++){
            Node node=(Node)nodes.get(i);
            s+="the node:"+node.getLabel();
            for(int j=0;j<node.getEdges().size();j++){
                Edge edge=(Edge) node.getEdges().get(j);
                s+="  points to: "+edge.getTo().getLabel()+" , this edge weight is: "+edge.weight;
            }
            s+="\n";
        }
        return s;
    }

}


