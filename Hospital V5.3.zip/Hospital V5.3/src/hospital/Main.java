package hospital;



public class Main {
    public static void main(String[] args) {

        Hospital hospital1 = new Hospital();

        Patient patient1 = new Patient("Patient1",1,true);
        Patient patient2 = new Patient("Patient2",2,false);
        Patient patient3 = new Patient("Patient3",3,false);
        Patient patient4 = new Patient("Patient4",2,false);
        Patient patient5 = new Patient("Patient5",2,true);
        Patient patient6 = new Patient("Patient6",1,true);
        Patient patient7 = new Patient("Patient7",2,false);
        Patient patient8 = new Patient("Patient8",3,true);
        Patient patient9 = new Patient("Patient9",2,false);
        Patient patient10 = new Patient("Patient10",3,true);
        Patient patient11 = new Patient("Patient11",2,false);
        Patient patient12 = new Patient("Patient12",1,false);

        Room room1 = new Room("101",1);
        Room room2 = new Room("102",1);
        Room room3 = new Room("107",2);
        Room room4 = new Room("108",2);
        Room room5 = new Room("109",2);
        Room room6 = new Room("103",2);
        Room room7 = new Room("104",2);
        Room room8 = new Room("110",2);
        Room room9 = new Room("111",2);
        Room room10 = new Room("105",2);
        Room room11 = new Room("106",2);
        Room room12 = new Room("112",2);
        Room room13 = new Room("113",2);
        Room room14 = new Room("114",2);
        Room room15 = new Room("115",2);
        Room room16 = new Room("116",2);
        Room room17 = new Room("121",2);
        Room room18 = new Room("122",2);
        Room room19 = new Room("117",2);
        Room room20 = new Room("118",2);
        Room room21 = new Room("123",2);
        Room room22 = new Room("124",2);
        Room room23 = new Room("119",2);
        Room room24 = new Room("120",2);
        Room room25 = new Room("125",2);
        Room room26 = new Room("126",2);

        Department department1 = new Department("Neurology");
        Department department2 = new Department("Cardiology");
        Department department3 = new Department("Radiology");
        Department department4 = new Department("Physiotherapy");
        Department department5 = new Department("Oncology");
        Department department6 = new Department("Radiotherapy");

        department1.addDevice("A");
        department1.addDevice("B");
        department2.addDevice("A");
        department3.addDevice("A");


        department1.addPatientRooms(room1);
        department1.addPatientRooms(room2);
        department1.addPatientRooms(room3);
        department1.addPatientRooms(room4);
        department1.addPatientRooms(room5);
        department2.addPatientRooms(room6);
        department2.addPatientRooms(room7);
        department2.addPatientRooms(room8);
        department2.addPatientRooms(room9);
        department3.addPatientRooms(room10);
        department3.addPatientRooms(room11);
        department3.addPatientRooms(room12);
        department3.addPatientRooms(room13);
        department4.addPatientRooms(room14);
        department4.addPatientRooms(room15);
        department4.addPatientRooms(room16);
        department4.addPatientRooms(room17);
        department4.addPatientRooms(room18);
        department5.addPatientRooms(room19);
        department5.addPatientRooms(room20);
        department5.addPatientRooms(room21);
        department5.addPatientRooms(room22);
        department6.addPatientRooms(room23);
        department6.addPatientRooms(room24);
        department6.addPatientRooms(room25);
        department6.addPatientRooms(room26);

        hospital1.addDepartments(department1);
        hospital1.addDepartments(department2);
        hospital1.addDepartments(department3);
        hospital1.addDepartments(department4);
        hospital1.addDepartments(department5);
        hospital1.addDepartments(department6);

        hospital1.connectDepartments(department1,department2);
        hospital1.connectDepartments(department1,department4);
        hospital1.connectDepartments(department2,department3);
        hospital1.connectDepartments(department2,department5);
        hospital1.connectDepartments(department3,department6);
        hospital1.connectDepartments(department4,department5);
        hospital1.connectDepartments(department5,department6);

        hospital1.signInPatientToDepartment(patient1,"Neurology");
        hospital1.signInPatientToDepartment(patient2,"Neurology");
        hospital1.signInPatientToDepartment(patient3, "Neurology");
        hospital1.signInPatientToDepartment(patient4, "Neurology");
        hospital1.signInPatientToDepartment(patient5,"Neurology");
        hospital1.signInPatientToDepartment(patient6,"Neurology");
        hospital1.signInPatientToDepartment(patient7,"Neurology");
        hospital1.signInPatientToDepartment(patient8,"Neurology");
        hospital1.signInPatientToDepartment(patient9,"Neurology");
        hospital1.signInPatientToDepartment(patient10,"Cardiology");
        hospital1.signInPatientToDepartment(patient11,"Oncology");
        hospital1.signInPatientToDepartment(patient12,"Cardiology");

        hospital1.signInPatientToPatientRoom();

        hospital1.signOutPatient(patient1);

        hospital1.printRouteFromTo("Neurology","Oncology");

        hospital1.printRouteFromToAvoiding("Neurology","Radiology","Cardiology");

        hospital1.printRouteFromToVia("Neurology","Physiotherapy","Cardiology");

        System.out.println(hospital1.getRoomNumberForPatientNamed("Patient2"));

        System.out.println(hospital1.closestDepartmentToWithDevice("Oncology","A"));

        System.out.print(hospital1);



    }

}
