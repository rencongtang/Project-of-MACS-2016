package hospital;

/***
 * For the part 3, we use this class hospital to deal with the problem.
 * At first, what the hospital contains? The registers and departments.
 * the registers contains the regist of the patients in a specific room,
 * when the patient sign in into a patient room, the register worked,
 * and for the departments, it contains the patient rooms and waiting rooms
 * you can add patient rooms into the department in this class, and add patient
 * into a specific room in the department.
 */

public class Hospital {
    private LinkedList registers = new LinkedList();
    private LinkedList departments= new LinkedList();
    public Hospital()
    {

    }

    public void addDepartments(Department department){
        departments.addLast(department);
    }

    // Your methods for setting up a hospital (adding departments etc.)

    /**
     * Add the specified device to a given department (specified by name).
     *
     * @param device          // String specifying the device
     * @param departmentName  // Name of the department
     */

    public void addDeviceToDepartment(String device, String departmentName)
    {
        for(int i=0;i<departments.size();i++){
            Department department = (Department) departments.get(i);
            if(department.getDepartmentName()==departmentName){
                department.addDevice(device);
            }
        }
    }

    /**
     * Sign in a patient to a given department (name).
     *
     * @param patient
     * @param departmentName
     */
    public void signInPatientToDepartment(Patient patient, String departmentName)
    {
        for(int i=0;i<departments.size();i++){// To find the department one by one,if th department is what you need, operate it, or you need to
            //push it back
            Department department = (Department) departments.get(i);
            if(department.getDepartmentName()==departmentName){
                department.addToWaitingRoom(patient);//add to a department, at first, patient is supposed to add into a patient room
                Register register=new Register();
                register.setPatientName(patient.getName());
                register.setRoomNumber(departmentName+"'s Waiting Room");
                register.setDepartment(department);
                registers.addLast(register);
                break;
            }
        }
    }

    public Department findDepartment(String departmentName){
        for(int i=0;i<departments.size();i++){
            Department department = (Department) departments.get(i);
            if(department.getDepartmentName()==departmentName){
//                Patient patient = department.outWaitingRoom();
                return department;
            }
            else{
                System.out.println("Sorry, no this department in this hospital");
            }
        }
        return null;
    }


    public void signInPatientToPatientRoom(){

        for(int i=0;i<departments.size();i++){
            Department department=(Department) departments.get(i);
            int patientsInWaitingRoom=department.getPatientNumberInWaitingRoom();
            for(int j=0;j<patientsInWaitingRoom;j++){
                Patient patient=department.outWaitingRoom();
                if(patient.getSingle()){
                    Room room=department.findSingleRoom();
                    if(room!=null){
                        Register register=room.signIn(patient);
                        for(int k=0;k<registers.size();k++){
                            if(((Register)registers.get(k)).getPatientName()==patient.getName()){
                                ((Register) registers.get(k)).setRoom(room);
                                ((Register) registers.get(k)).setRoomNumber(room.getRoomName());
                            }
                        }
//                        register.setRoom(room);
//                        registers.addLast(register);
                    }
                    else{
                        department.addBackToSingleWaitingRoom(patient);
                    }
                }
                else{
                    Room room1=department.findAvailableRoom();
                    if(room1!=null){
                        Register register=room1.signIn(patient);
                        for(int k=0;k<registers.size();k++){
                            if(((Register)registers.get(k)).getPatientName()==patient.getName()){
                                ((Register) registers.get(k)).setRoom(room1);
                                ((Register) registers.get(k)).setRoomNumber(room1.getRoomName());
                            }
                        }
//                        register.setRoom(room1);
//                        registers.addLast(register);
                    }
                    else {
                        department.addBackToNormalWaitingRoom(patient);
                    }
                }
            }
        }

    }




    /**
     * Sign out a patient from the hospital.
     *
     * @param patient
     */
    public void signOutPatient(Patient patient)
    {
        String patientName=patient.getName();
        for(int i=0;i<registers.size();i++){
            Register register=(Register) registers.get(i);
            if(patientName==register.getPatientName()){
                Room room=register.getRoom();
                if(room!=null){
                    room.signOut(patient);
                    registers.remove(i);
                    Department department=register.getDepartment();


                    if((room.getCapacity()==1)&&(department.singleWaitingRoomCount()!=0)){
                        Patient patient1=department.outSingle();
                        for(int j=0;j<registers.size();j++){
                            if(patient1.getName()==((Register)registers.get(j)).getPatientName()){
                                registers.remove(j);

                            }
                        }

                        Register register1=room.signIn(patient1);
                        register1.setDepartment(department);
                        register1.setRoomNumber(room.getRoomName());
                        register1.setRoom(room);
                        registers.addLast(register1);
                    }

                    else if(department.normalWaitingRoomCount()!=0){
                        Patient patient2=department.outNormal();
                        for(int j=0;j<registers.size();j++){
                            if(patient2.getName()==((Register)registers.get(j)).getPatientName()){
                                registers.remove(j);

                            }
                        }
                        Register register2=room.signIn(patient2);
                        register2.setRoomNumber(room.getRoomName());
                        register2.setDepartment(department);
                        register2.setRoom(room);
                        registers.addLast(register2);
                    }

                }
                else {
                    System.out.println("Patient: "+patientName+" is not in patient room");
                }
            }
        }
    }

    /**
     * Get the room number (or name) for a given patient (name).
     *
     * @param name
     * @return The room number as String or the name of the room.
     */
    public String getRoomNumberForPatientNamed(String name){
        boolean flag =false;// To make a flag for true and false
        for(int i=0;i<registers.size();i++){//check the elements of queue one by one
            Register register = (Register) registers.get(i);
            if(register.getPatientName()==name){
                flag = true;
//              System.out.println("The patient: "+name+"is at "+register.getRoomNumber());
                return register.getRoomNumber();
            }
        }
        if(flag==false){
            System.out.println("Sorry, can't find patient "+name);
        }
        return null;

    }
//	public String getRoomNumberForPatientNamed(String name)
//	{
//		// ...
//	}

    /**
     * Print the shortest route from one department to another.
     *
     * @param from  Name of the department to start from.
     * @param to    Name of the department to go to.
     */
    public void printRouteFromTo(String from, String to)
    {
        // ...
    }

    /**
     * Print the shortest route from one department to another, avoiding a third given department.
     *
     * @param from      Name of the department to start from.
     * @param to        Name of the department to go to.
     * @param avoiding  Name of the department to avoid.
     */
    public void printRouteFromToAvoiding(String from, String to, String avoiding)
    {
        // ...
    }

    /**
     * Print the shortest route from one department to another, via a third given department.
     *
     * @param from  Name of the department to start from.
     * @param to    Name of the department to go to.
     * @param via   Name of the department to pass through.
     */
    public void printRouteFromToVia(String from, String to, String via)
    {
        // ...
    }

    /**
     * Find the closest department to a given department that has a given device.
     *
     * @param dep     Name of the given department.
     * @param device  Name of the device.
     * @return Name of the closest department where the given device can be found.
     */
//	public String closestDepartmentToWithDevice(String dep, String device)
//	{
//		// ...
//	}
//
//	/**
//	 * Print the current status of the hospital.
//	 * Should include a list of patients and their roomnumbers (register)
//	 * and departments (name, rooms, patients/room -including patient names-, status waiting room)
//	 *
//	 */
//	public String toString()
//	{
//		// ...
//	}
}
